from django.shortcuts import redirect
from django.urls import reverse

class CheckUserLoggedInMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.process_request(request)
        if response:
            return response
        return self.get_response(request)

    def process_request(self, request):
        if 'user' not in request.session:
            if request.path not in [reverse('user_login'), reverse('register')]:
                return redirect('user_login')  # Redirect to login page if session user is not present
        # if 'user' in request.session:
        #     return none
        return None
from django.shortcuts import render,redirect, HttpResponse
from .models import *
from django.contrib import messages
from store.forms import CustomUserForm,LoginForm
from django.contrib.auth import authenticate, login
from .models import Logins, CartModel,Order, ReviewModel
from django.contrib.auth.hashers import make_password, check_password
from django.contrib import messages
from django.shortcuts import render, redirect
from .forms import CustomUserForm, LoginForm
from django.core.mail import send_mail
import random



def encrypt_password(password):
    hashed_password = make_password(password)
    return hashed_password



# Create your views here.
def home(request):
    return render(request,"store/index.html")

def collections(request):
    catagory = Category.objects.filter(status=0)
    context = {'catagory': catagory}
    return render(request,'store/collections.html',context)

def collectionsview(request,slug):
    if(Category.objects.filter(slug=slug, status=0)):
        products = Product.objects.filter(category__slug=slug)
        category =Category.objects.filter(slug=slug).first()
        context ={'products':products,'category_name':category}
        return render(request,"store/products/index.html",context)
    else:
        messages.warning(request,"no category")
        return redirect('collections')
    
def productview(request,cate_slug,prod_slug):
    if(Category.objects.filter(slug=cate_slug,status=0)):
        if(Product.objects.filter(slug=prod_slug,status=0)):
            products = Product.objects.filter(slug=prod_slug,status=0).first()
            context = {'products':products}

        else:
            messages.error(request,'no pdt found ')
            return redirect('collections')

    else:
        messages.error(request,'something wrong')
        return redirect('collections')
    return  render(request,"store/products/view.html",context)



def send(username):
   
    subject = 'Registeration Confirmation'
    otp = generate_otp()
    message = f'Hello {username},\n\n : This is the OTP for your registration : {otp}.' 
    from_email = 'dhaneshthampi10@gmail.com'
    to_email =  ['dhaneshthampi10@gmail.com']  
    send_mail(subject, message, from_email, to_email)
    return otp

def verify_otp(request):
    print('reached')
    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        print(entered_otp)
        email = request.session['reg_useremail']
        user =  Logins.objects.filter(email=email).first()
        print(user.otp)

        if user and user.otp == entered_otp:
                user.otp = None  
                user.registration_status = True
                user.save()
                messages.success(request, 'OTP verified. You can now complete your registration.')
                return redirect('user_login')
        else:
            messages.error(request, 'Invalid OTP. Please try again.')
    return render(request, 'store/auth/otpvaliidation.html')


def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        address = request.POST.get('adress')
        hashedPassword = encrypt_password(password)
        otp = send(username)
        print("REACHED0", email,otp)
        user_obj = Logins(username=username, email=email, password=hashedPassword, otp = otp, address=address)
        request.session['reg_useremail'] = email

        user_obj.save()
        return redirect('verify_otp')
       
    return render(request, "store/auth/register.html")

def user_login(request):
    if request.method == 'POST':
        email=request.POST['email']
        password =request.POST['password']
        
        user = Logins.objects.filter(email= email).first()
        if user:
            if check_password(password, user.password):
                request.session['user'] = user.username
                messages.success(request, 'Login successful!')
                return render(request,'store/index.html')

    return render(request, "store/auth/login.html")




# ADD TO CART LOGIC
def add_to_cart(request, product_id):
    user = request.session['user']
    cart_obj = CartModel(username= user, product_id=product_id)
    cart_obj.save()
    return redirect('view_cart')
    
   

from collections import Counter
def view_cart(request):
    current_user = request.session['user']
    cart_of_user = CartModel.objects.filter(username = current_user)
    product_names = [item.product_id for item in cart_of_user]

    product_counts = Counter(product_names)
    product_counts_dict = dict(product_counts)
    product_list = []
    
    for key, value in product_counts_dict.items():
        product={}
        product_of_key = Product.objects.filter(id = key).first()
        product[product_of_key.name] = {
            "product_info" : product_of_key,
            'quantity': value
        }
        product_list.append(product)
    return render(request, 'store/products/cart_view.html', {"products": product_list})

def buynow(request,id):
    context ={'product_id':id}
    return render(request,'store/products/payment.html',context)

def payment(request, id):
    user = request.session.get('user')
    if user:
        order = Order(product_id=id, username=user)
        order.save()
        try:
            cart_item = CartModel.objects.get(product_id=id, username=user)
            cart_item.delete()
        except CartModel.DoesNotExist:
            pass
        subject = 'Order Confirmation'
        message = f'Hello {user},\n\nThank you for your order. Your order has been confirmed.' #edited
        from_email = 'dhaneshthampi10@gmail.com'
        to_email =  ['dhaneshthampi10@gmail.com']  
        send_mail(subject, message, from_email, to_email)

        alert_message = "Payment Successful! Thank you for your purchase."
        return HttpResponse(f'<script>alert("{alert_message}");</script>')
    else:
        return HttpResponse('<script>alert("Please login to continue."); window.location.replace("/login");</script>')

def remove_product(request, id):
    user = request.session['user']
    cart_of_user = CartModel.objects.filter(username = user, product_id=id)
    cart_of_user.delete()

    return redirect('view_cart')

def search(request):
    search_word = request.POST.get('search')
   
    search_catagories = Category.objects.filter( name=search_word).first()
    if search_catagories:

        print(search_catagories.id)
        search_items= Product.objects.filter(category= search_catagories.id)
        print(search_items)
        context= {'products': search_items}
        return render(request, 'store/products/product_view.html',context)
    return render(request,'store/index.html')

from django.shortcuts import redirect

def user_logout(request):
  
    if 'user' in request.session:
        del request.session['user']
    return redirect('user_login')  



def review(request):
    if request.method == "GET":
        username = request.session['user']
        all_orders_user = Order.objects.filter(username = username)
        product_list = [order.product_id for order in all_orders_user if order.status]
        product_list = set(product_list)
        

        list_of_product = []
        for id in product_list:
            product = Product.objects.filter(id = id).first()
            list_of_product.append(product)

        print(list_of_product)

        return render(request, 'store/Reviews/ViewProducts.html', {'all_products':list_of_product})
    elif request.method == "POST":
        user = request.session['user']
        product_id = request.POST.get('product_id')
        feedback = request.POST.get('feedback')
        review_obj = ReviewModel(username = user, product_id=product_id, feedback=feedback)
        review_obj.save()
        return redirect('review')


def single_review(request, id):
    context = {
        'product' : id,
    }
    return render(request, 'store/Reviews/makeReview.html', context)


# ---------------------------------------------------------------------------
def view_orders(request):
    current_user = request.session.get('user')
    if current_user:
        orders = Order.objects.filter(username=current_user)
        order_details = []
        for order in orders:
            try:
                product = Product.objects.get(id=order.product_id)
                order_detail = {'order': order, 'product': product}
                order_details.append(order_detail)
            except Product.DoesNotExist:
                pass
        return render(request, 'store/products/vieworder.html', {'order_details': order_details})
    else:
        return render(request, 'login.html', {'error_message': 'Please log in to view your orders.'})
    

# ---------------------------------------------------------------------------






def change_password(request):#doubt
    if request.method == 'POST':
        email = request.POST.get('email')
        current_password = request.POST.get("current_password")
        new_password = request.POST.get("new_password")
        hashed_pass = encrypt_password(new_password)

        user = Logins.objects.filter(email= email).first()
        if user:
            if check_password(current_password, user.password):
                user.password = hashed_pass
                user.save()
                return redirect("user_login")
    return render(request, 'store/auth/change_password.html')



def generate_otp():
        # Generate a random 6-digit OTP
        return str(random.randint(100000, 999999))




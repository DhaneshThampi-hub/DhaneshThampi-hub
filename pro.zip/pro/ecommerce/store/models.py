from django.db import models
from django.contrib.auth.models import User
import datetime
import os
# Create your models here.

def get_file_path(request,filename):
    orginal_filename = filename
    nowTime = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename ="%s%s" % (nowTime,orginal_filename)
    return os.path.join('uploads/',filename)



class Category(models.Model):
    slug = models.CharField(max_length=150,null=False,blank=False)
    name = models.CharField(max_length=150,null=False,blank=False)
    image = models.ImageField(upload_to=get_file_path, null=True,blank=True)
    description = models.TextField(max_length=500,null=False,blank=False)
    status = models.BooleanField(default=False,help_text="0=default, 1=Hidden")
    trending = models.BooleanField(default=False,help_text="0=default, 1=Hidden")
    meta_title = models.CharField(max_length=150,null=False)
    meta_keywords = models.CharField(max_length=150,null=False)
    meta_description = models.TextField(max_length=500,null=False,blank=False)
    created_at = models.DateTimeField( auto_now_add=True)

    def __str__(self):
        return self.name
    

class Product(models.Model):
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    slug = models.CharField(max_length=150,null=False,blank=False)
    name = models.CharField(max_length=150,null=False,blank=False)
    product_image = models.ImageField(upload_to=get_file_path, null=True,blank=True)
    small_description = models.CharField(max_length=250,null=False,blank=False)
    quantity = models.IntegerField(null=False,blank=False)
    description = models.TextField(max_length=500,null=False,blank=False)
    orginal_price =models.FloatField(null=False,blank=False)
    selling_price =models.FloatField(null=False,blank=False)
    status = models.BooleanField(default=False,help_text="0=default, 1=Hidden")
    trending = models.BooleanField(default=False,help_text="0=default, 1=Hidden")
    tag = models.CharField(max_length=150,null=False,blank=False)
    meta_title = models.CharField(max_length=150,null=False)
    meta_keywords = models.CharField(max_length=150,null=False)
    meta_description = models.TextField(max_length=500,null=False,blank=False)
    created_at = models.DateTimeField( auto_now_add=True)

    def __str__(self):
        return self.name
    



class Logins(models.Model):
    username = models.EmailField(max_length=30, unique=True)
    password = models.CharField(max_length=30)
    email = models.EmailField(unique=True)
    otp = models.CharField(max_length=10,null=True)
    registration_status = models.BooleanField(default=False)
    address = models.CharField(max_length=100)

#edited    

class CartModel(models.Model):
    username = models.CharField(max_length=30)
    product_id = models.IntegerField()
    def __int__(self):
        return self.product_id #edited

class Order(models.Model):
    product_id = models.IntegerField()
    username = models.CharField(max_length=50)
    status = models.BooleanField(default=False)
    

class ReviewModel(models.Model):
    product_id = models.IntegerField()
    username = models.CharField(max_length=20)
    feedback = models.TextField(max_length=200)
from django.urls import path
from  store import views



urlpatterns = [
    path('home',views.home,name='home'),
    path('collections',views.collections,name='collections'),
    path('collections/<str:slug>',views.collectionsview,name='collectionsview'),
    path('collections/<str:cate_slug>/<str:prod_slug>',views.productview,name='productview'),
    path('register/',views.register,name='register'),
    # path('user_login',views.user_login,name='user_login'),
    path('',views.user_login,name='user_login'),
    path('add_to_cart/<product_id>', view=views.add_to_cart, name='add_to_cart'),
    path('view_cart', views.view_cart, name='view_cart'),
    path('buynow/<id>', views.buynow, name='buynow'),
    path('payment/<id>',views.payment,name='payment'),
    path('remove_product/<id>',views.remove_product,name='remove_product'),
    path('search/',views.search,name='search'),
    path('user_logout',views.user_logout,name='user_logout'),
    path('review/', views.review, name='review'),
    path('review/<id>', views.single_review, name='single_review'),
    path('view_orders',views.view_orders,name='view_orders'),
    path('change_password',views.change_password,name='change_password'),
    path('verify_otp',views.verify_otp,name='verify_otp'),
]